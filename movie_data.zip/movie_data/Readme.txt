本数据集为电影评论极性分析数据集，包含：
	training.tsv	16000条
	validation.tsv	2000条
	test.tsv		2001条
	submit.tsv
	
	submit.tsv为提交测试结果的格式，其中：
		每一行为一个评论的id和预测的极性，二者以"\tab"隔开
		id要与本文件夹中test.tsv中id的顺序保持一致
		